import java.util.Random;
import java.util.Scanner;

public class game {

    public static void main(String[] args) {
        // Tworzymy obiekt klasy Random, który posłuży do losowania liczby
        Random random = new Random();

        // Losujemy liczbę z zakresu od 1 do 100
        int numberToGuess = random.nextInt(100) + 1;

        // Tworzymy obiekt klasy Scanner, który posłuży do odczytywania wejścia od użytkownika
        Scanner scanner = new Scanner(System.in);

        int userGuess = 0;
        int numberOfTries = 0;

        // Wprowadzamy pętlę do zgadywania liczby
        while (userGuess != numberToGuess) {
            System.out.print("Zgadnij liczbę (1-100): ");

            // Odczytujemy liczbę podaną przez użytkownika
            userGuess = scanner.nextInt();
            numberOfTries++;

            // Sprawdzamy, czy liczba jest za wysoka, za niska, czy prawidłowa
            if (userGuess < numberToGuess) {
                System.out.println("Za mało! Spróbuj ponownie.");
            } else if (userGuess > numberToGuess) {
                System.out.println("Za dużo! Spróbuj ponownie.");
            } else {
                System.out.println("Gratulacje! Zgadłeś liczbę w " + numberOfTries + " próbach.");
            }
        }

        // Zamykamy skaner, aby uniknąć wycieków pamięci
        scanner.close();
    }
}
